package com.cooliris.media;

public abstract class MediaFilter {
    public abstract boolean pass(MediaItem item);
}
