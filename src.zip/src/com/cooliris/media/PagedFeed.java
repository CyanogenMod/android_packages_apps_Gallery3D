package com.cooliris.media;

public abstract class PagedFeed<E> extends VirtualFeed<E> {

    @Override
    public void setLoadingRange(int begin, int end) {
    }

}
