//package com.cooliris.media;
//
//// Deprecated class. Need to remove from perforce.
//
//import javax.microedition.khronos.opengles.GL11;
//
//public final class ContextMenu extends Layer {
//
//    public void openWithRect(int x, int y, int width, int height) {
//
//    }
//
//    public void close() {
//
//    }
//
//    @Override
//    public void renderBlended(RenderView view, GL11 gl) {
//        gl.glClear(GL11.GL_COLOR_BUFFER_BIT);
//    }
//
//    @Override
//    public void generate(RenderView view, RenderView.Lists lists) {
//        lists.blendedList.add(this);
//        lists.hitTestList.add(this);
//    }
//}
