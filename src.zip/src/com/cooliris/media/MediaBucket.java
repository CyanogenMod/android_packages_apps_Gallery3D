package com.cooliris.media;

import java.util.ArrayList;

public class MediaBucket {
    public MediaSet mediaSet;
    public ArrayList<MediaItem> mediaItems;
}
