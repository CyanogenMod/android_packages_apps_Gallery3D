package com.cooliris.cache;

public class ImageList {
    public long ids[];
    public long thumbids[];
    public long timestamp[];
    public int orientation[];
}
